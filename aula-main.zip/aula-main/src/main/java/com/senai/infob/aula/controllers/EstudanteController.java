package com.senai.infob.aula.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.senai.infob.aula.models.Estudante;
import com.senai.infob.aula.services.EstudanteService;



@RestController
public class EstudanteController {
    
    @Autowired
    public EstudanteService estudanteService ;

    @GetMapping("/count")
    public Long count() {
        return estudanteService.count();
    }
    
    @PostMapping("/salvar")
    public Estudante salvar(@RequestBody Estudante estudante) { 
        return estudanteService.salvar(estudante);
    }
    
    @DeleteMapping("/deletar/{id}")
    public String deletar(@PathVariable Integer id){
       // if estudanteService.deletar(id);{
       // return "Usuario deletado com sucesso";
        //} else {
        //    return "Usuario nao encontrado";
        //}
    }
}